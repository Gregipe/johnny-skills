---
name: voice-ai-demo-landing-page
description: "Re-brand a Hunar voice-AI demo landing page for a client."
version: 1.0.0
author: Greg Ipe
metadata:
  hermes:
    tags: [hunar, voice-ai, cloudflare-workers, demo, branding, react]
    category: deployment
---

# Voice-AI Demo Landing Page Skill

Hunar.ai client pitch demos are single-page apps where a visitor enters their name/number (plus optional fields), triggers a real Hunar voice-agent call to their own phone, and watches call progress live while results log to a Google Sheet. This skill covers the reference architecture and how to clone + re-brand an existing demo (e.g. Bajaj HF → Mondelez India) for a new client.

## When to Use

- Cloning an existing Hunar demo page for a new client / pitch
- Re-branding colors, logo, and copy on one of these pages
- Understanding or debugging the Worker proxy + Sheets logging layer

## Reference Architecture

Three real files + config:

- `public/index.html` — single-file React (CDN React 18 + Babel standalone, no build step). Three views: application form → call monitor → "About Hunar.ai".
- `src/index.js` — Cloudflare Worker. Proxies `/api/calls` (POST) and `/api/calls/:id` (GET) to the Hunar API with a server-side `X-API-Key`; `/api/log` (POST) appends a row to a Google Sheet via a service-account JWT; `/api/sheets/init` writes headers; everything else falls through to the `ASSETS` binding.
- `wrangler.jsonc` — worker `name`, assets binding, `nodejs_compat`.
- Secrets in `.dev.vars` (gitignored): `HUNAR_API_KEY`, `GOOGLE_SERVICE_ACCOUNT_JSON`.

See `references/hunar-api-and-sheet-logging.md` for the exact endpoints, JWT flow, and the 23-column sheet schema.

## Prerequisites

- Node 22 + `npx` (wrangler runs via `npx wrangler dev` — no global install).
- The target client's agent UUID on Hunar's platform, or keep the previous UUID as a placeholder (see Pitfalls).
- Network for CDN React + the client's hotlinked logo.

## How to Re-brand (Procedure)

1. Clone full history: `git clone <existing-demo-repo> ~/<new-client>-voice-ai`.
2. Extract the client's real branding — see `references/brand-extraction.md`. Never guess colors; pull computed styles from their live site.
3. Decide the sidebar theme from the logo color: white logo → dark/purple sidebar; colored logo → light sidebar. Measure the logo's dominant pixel color before choosing.
4. Apply all string edits as ONE verified replacement script (see `references/verified-replacement-edit.md`), asserting each old-string count. Never hand-transcribe a ~36 KB single-file React page.
5. Keep the previous agent UUID with a `// TODO: swap id ...` comment; update the worker name in `wrangler.jsonc`.
6. Run `CI=1 npx --yes wrangler dev --port 8787` (background), then confirm it actually serves via `curl -s -o /dev/null -w '%{http_code}' localhost:8787` and `lsof -nP -iTCP:8787 -sTCP:LISTEN`. Do NOT wait for a "Ready on http" log line — see Pitfalls.
7. Leave `src/index.js` logging target (`SHEET_ID` / range) as-is until the real agent is wired up — note it for the switch.

## Quick Reference

| What | Where |
|------|-------|
| Hunar API base | `https://api.voice.hunar.ai/external/v1` |
| Agent identity | `const AGENT = {...}` in `index.html` |
| Worker name | `wrangler.jsonc` `name` |
| Log target | `SHEET_ID` + `SHEET_RANGE` in `src/index.js` |
| Secrets | `.dev.vars` (`HUNAR_API_KEY`, `GOOGLE_SERVICE_ACCOUNT_JSON`) |

## Pitfalls

- **Agent UUID is the critical dependency.** The page is inert without a live agent on Hunar. Keep the previous UUID as a clearly-marked placeholder and swap later.
- **In-place re-brand kills the old demo** if the previous client is still being shown the page. Clone to a new repo; keep both live.
- **Sheet schema is hardcoded** to the previous agent's `result` fields. Making `/api/log` generic (core call fields + flatten `result`) survives agent-prompt changes.
- **Logo color determines sidebar color.** The Mondelez logo measured white (254,254,254) even though their brand is purple — so a purple sidebar worked. Always measure, don't assume.
- **`/api/debug-key` leaks part of the service-account private key** in the reference repo — remove before any non-demo deployment.
- **Open endpoints + no rate limit** — anyone with the URL can trigger calls. Fine for a pitch demo; flag before anything public.
- **`.wrangler/cache/wrangler-account.json` is committed** in the reference repo — gitignore `.wrangler/`.
- **Verified-replacement cascade bug** — when one replacement's target string appears inside another's target, applying the first makes the second report "NOT FOUND". Order broad replaces last, and skip (don't apply) any edit whose expected count mismatches. See `references/verified-replacement-edit.md`.
- **Renaming a color constant does not change its literal value.** `NAVY`→`PURPLE` / `ORANGE`→`ACCENT` renames every *reference* but leave the hex in `const ACCENT="#FF6700"` orphaned (old brand color still live). Update the hex too, then run the full color audit (see Verification).
- **`npx wrangler dev` runs silently.** First run can hang forever waiting on the npx "Ok to proceed?" install prompt (background processes have no stdin), and even once `workerd` is up the console may emit nothing while the server is fine. Always `npx --yes` (auto-accept) and verify readiness with `lsof` + `curl`, never by waiting for a log line.

## Verification

- `curl -s localhost:8787` returns HTML containing the new title and logo URL.
- `grep` the page for the old brand name / old color hexes — should return only intentional leftovers (e.g. the placeholder agent UUID).
- **Full color audit:** `curl -s localhost:8787/ | grep -oE '#[0-9A-Fa-f]{6}' | sort | uniq -c | sort -rn` — confirm only neutrals, semantic status colors (green/blue/amber/red pipeline states), and the new brand colors remain. Zero old-brand hexes (this is what catches the orphaned-color-value bug).
- Open `localhost:8787` and visually confirm sidebar, logo, and CTA colors.
